# Color Spaces in OpenCV C++ and Python

The repository contains code for the blog post [Color Spaces in OpenCV C++ and Python](https://www.learnopencv.com/color-spaces-in-opencv-cpp-python/).

<p align="center"><img src="https://learnopencv.com/wp-content/uploads/2017/05/color-change-illumination.gif" alt="OpenCV Color Spaces"></p>

[<img src="https://learnopencv.com/wp-content/uploads/2022/07/download-button-e1657285155454.png" alt="download" width="200">](https://www.dropbox.com/scl/fo/q7kiq1o8xco4b9407d3yo/h?dl=1&rlkey=gs2vchtmmawz3ltaem99lojxy)

# AI Courses by OpenCV

Want to become an expert in AI? [AI Courses by OpenCV](https://opencv.org/courses/) is a great place to start. 

<a href="https://opencv.org/courses/">
<p align="center"> 
<img src="https://www.learnopencv.com/wp-content/uploads/2020/04/AI-Courses-By-OpenCV-Github.png">
</p>
</a>
